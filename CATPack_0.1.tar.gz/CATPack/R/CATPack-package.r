#' CATPack
#'
#' @name CATPack
#' @docType package
NULL

.onUnload <- function (libpath) {
  library.dynam.unload("CATPack", libpath)
}