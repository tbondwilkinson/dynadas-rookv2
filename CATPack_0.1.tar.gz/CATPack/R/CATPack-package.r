#' CATPack
#'
#' @name CATPack
#' @docType package
NULL
